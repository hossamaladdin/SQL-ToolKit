@echo off
REM set mypath=%cd%
REM color 1f
echo Welcome to Tradeplus Setup
echo.
pause

cd /d "%~dp0"
REM echo %cd%

REM color 0a
set RegKey=HKLM\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL
rem Check if registry key exists
reg query "%RegKey%" > nul 2>&1
if %errorlevel% equ 0 (
    rem Registry key exists, go to position A
	goto checkinstance
) else (
    rem Registry key does not exist, go to position B
	echo.
	echo No previous instances found, continuing installation
	echo.
   goto install
)
:checkinstance

REM List all SQL Server instances and their versions
echo.
echo Checking existing SQL Server instances:
echo ----------------------------------------
setlocal enabledelayedexpansion

for /f "tokens=2*" %%i in ('reg query "HKLM\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL" /s ^| find "REG_SZ" ^| find /v "Cluster"') do (
    set instancename=%%j
    set instancename=!instancename:*.=!
    set "sqlcmdoutput="
    for /f "delims=" %%k in ('sqlcmd -S "localhost\!instancename!" -Q "SELECT @@VERSION" 2^>nul ^| findstr /B /C:"Microsoft SQL Server"') do (
        set "sqlcmdoutput=%%k"
    )
    if not defined sqlcmdoutput (
        echo Cannot connect to instance !instancename!.
    )else (
		echo Installed SQL instances are:
		echo !instancename! - !sqlcmdoutput!
		echo.
		if "!instancename!"=="TRUEBOOK" (
		set installed=1
		set truebook=1
		)
	)
    echo.
)

REM If user chooses to exit, exit the script
REM setlocal enabledelayedexpansion
REM if "%truebook%"=="1" (
		REM set /p continue="An instance named TRUEBOOK was found, Do you still want to continue with the installation? [Y/N]"
		REM if /i not "%continue%"=="Y" (
		REM echo Exiting the batch file...
		REM goto exit
		REM )
REM )

:install
REM Continue with installation code here

set /p drive=Please enter installation drive letter like this (C , D , E):
echo.
for /f "tokens=2 delims==" %%a in ('wmic logicaldisk where "DeviceID='%drive%:'" get caption /value') do set partition=%%a

if "%partition%"=="" (
	REM color 4f
    echo Drive %drive% does not exist or is not a valid partition, please make sure not to use colons `:`
    pause
    exit /b 1
)

REM color 3b
echo Files will be installed on drive %partition%.
echo.

REM setting main setup directories
set homedir=%partition%\TRUEBOOK
set installdir=%homedir%\SETUP
set downloadpath=%homedir%\DOWNLOAD
set extractdir=%installdir%\SQL_2014
set ConfigurationFile=%installdir%\ConfigurationFile.ini

REM creating main directories
mkdir %homedir%
mkdir %installdir%
mkdir %homedir%\ARCHIVE
mkdir %homedir%\BACKUP
mkdir %homedir%\REPORTS
mkdir %downloadpath%

REM creating base configfile
echo ;This is a config file for the installation > %installdir%\InstallationConfig.ini
echo ;FEATURES=SQLENGINE>>  %installdir%\InstallationConfig.ini
echo FEATURES=SQL, Tools>>  %installdir%\InstallationConfig.ini
echo INSTANCENAME=TRUEBOOK>>  %installdir%\InstallationConfig.ini
echo SERVERADMIN=ADMINISTRATORS>>  %installdir%\InstallationConfig.ini
echo SQLSVCACCOUNT=NT AUTHORITY\NETWORK SERVICE>>  %installdir%\InstallationConfig.ini
echo SECURITYMODE=SQL>>  %installdir%\InstallationConfig.ini
echo SA_PASSWORD=<SA_PASSWORD>>>  %installdir%\InstallationConfig.ini
echo BROWSERSVCSTARTUPTYPE="Automatic">>  %installdir%\InstallationConfig.ini
echo UpdateEnabled=False>>  %installdir%\InstallationConfig.ini
echo ;SQLCOLLATION=SQL_Latin1_General_CP1_CI_AS>>  %installdir%\InstallationConfig.ini
echo ;SQLSVCPASSWORD=<SQLSVC_PASSWORD>>> %installdir%\InstallationConfig.ini

REM  Read parameters from config file
for /f "tokens=1,* delims==" %%a in (%installdir%\InstallationConfig.ini) do (
  set %%a=%%b
)

REM goto restore

icacls "%homedir%\BACKUP" /grant "%SQLSVCACCOUNT%:F"
REM "!SQLSVCACCOUNT!:(OI)(CI)F"

REM  Create ConfigurationFile.ini
REM color 3b
echo Preparing configuration file
echo .
echo ;SQL Server 2014 Express Configuration File > %ConfigurationFile%
echo [OPTIONS] >> %ConfigurationFile%
echo ACTION="Install" >> %ConfigurationFile%
echo QUIET="True" >> %ConfigurationFile%
echo TCPENABLED=1 >>  %ConfigurationFile%
echo NPENABLED=1 >>  %ConfigurationFile%
echo FEATURES="%FEATURES%" >> %ConfigurationFile%
echo INSTANCENAME="%INSTANCENAME%" >> %ConfigurationFile%
echo SQLSVCACCOUNT="%SQLSVCACCOUNT%" >> %ConfigurationFile%
echo SECURITYMODE=%SECURITYMODE% >> %ConfigurationFile%
echo SAPWD=%SA_PASSWORD%>> %ConfigurationFile%
echo SQLSYSADMINACCOUNTS="%SERVERADMIN%" >> %ConfigurationFile%
REM echo SQLCOLLATION="%SQLCOLLATION%" >> %ConfigurationFile%
REM echo INSTANCEDIR="%INSTALLDIR%" >> %ConfigurationFile%
REM echo INSTALLSHAREDDIR="%INSTALLDIR%" >> %ConfigurationFile%
REM echo INSTALLSHAREDWOWDIR="%INSTALLDIR%\x86" >> %ConfigurationFile%
REM  Add more parameters and values according to your needs
REM pause

REM finding correct windows architecture
for /f "tokens=1,2 delims=:" %%a in ('systeminfo ^| find "Type"') do (
    set "os=%%b"
)

set "os=%os: =%"
set "str=%os:~0,3%"

REM color 3b
echo Your Windows architecture is %str%
echo.

REM Enable all SSL and TLS versions in Internet Options

REM Enable SSL 2.0, SSL 3.0, TLS 1.0, TLS 1.1, and TLS 1.2
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings" /v "SecureProtocols" /t REG_DWORD /d 0x00000A80 /f
REG ADD HKLM\System\CurrentControlSet\Control\SecurityProviders\SCHANNEL /v ignoreRootCerts /t REG_DWORD /d 1 /f
REG ADD HKLM\System\CurrentControlSet\Control\SecurityProviders\SCHANNEL /v disableCertRevocationCheck /t REG_DWORD /d 1 /f
REG ADD HKLM\System\CurrentControlSet\Control\SecurityProviders\SCHANNEL /v certChain /t REG_DWORD /d 1 /f
REG ADD HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Certificates\SHA1RSAPRSA /v CertCheck /d 2 /f
REG ADD HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Certificates\SHA-256 /v CertCheck /d 2 /f
REG ADD HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Certificates\SHA-384 /v CertCheck /d 2 /f
REG ADD HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Certificates\SHA-512 /v CertCheck /d 2 /f

:: Set minRSAPubKeyBitLength to 256
certutil -setreg chain\minRSAPubKeyBitLength 256>nul

set DOTNET_VER=4.0
set REGKEY="HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full"
set REGVAL="Version"
rem set "url=https://download.visualstudio.microsoft.com/download/pr/2d6bb6b2-226a-4baa-bdec-798822606ff1/9b7b8746971ed51a1770ae4293618187/ndp48-web.exe"
set "url=https://download.microsoft.com/download/9/5/A/95A9616B-7A37-4AF6-BC36-D6EA96C8DAAE/dotNetFx40_Full_x86_x64.exe"
set "downloadedfile=%downloadpath%\dotNetFx40_Full_x86_x64.exe"
	
echo Checking if .NET Framework %DOTNET_VER% is installed...

reg query %REGKEY% /v %REGVAL% >nul 2>&1
if "%ERRORLEVEL%"=="0" (
    echo .NET Framework %DOTNET_VER% is already installed.
) else (
    echo .NET Framework %DOTNET_VER% is not installed. Downloading and installing...
	
    IF NOT EXIST %downloadedfile% powershell -command "$AllProtocols = [System.Net.SecurityProtocolType]::Tls12; $client = New-Object System.Net.WebClient; [System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}; $client.DownloadFile('%url%', '%downloadedfile%')"
  
    start /wait %downloadedfile% /q /norestart

    echo .NET Framework %DOTNET_VER% has been installed.
)



REM  Set the file name and URL based on the windows architecture
if /i "%str%"=="x86" set filename=SQLEXPR_x86_ENU.exe & set url=https://download.microsoft.com/download/E/A/E/EAE6F7FC-767A-4038-A954-49B8B05D04EB/Express 32BIT/SQLEXPR_x86_ENU.exe
if /i "%str%"=="x64" set filename=SQLEXPR_x64_ENU.exe & set url=https://download.microsoft.com/download/E/A/E/EAE6F7FC-767A-4038-A954-49B8B05D04EB/Express 64BIT/SQLEXPR_x64_ENU.exe

set downloadedfile=%downloadpath%\%filename%

if "%installed%"=="1" goto restore
REM  Download the file using bitsadmin command
echo Downloading and installing SQL Server 2014
IF NOT EXIST %downloadedfile% powershell -command "$AllProtocols = [System.Net.SecurityProtocolType]::Tls12; $client = New-Object System.Net.WebClient; [System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}; $client.DownloadFile('%url%', '%downloadedfile%')"

REM  Display a message when the download is complete
REM color 0a
echo Download complete!
echo.

REM Extracting setup files
REM color 3b
echo Extracting files to %extractdir%
echo.
%downloadedfile% /q /x:%extractdir%

REM Installing SQL
REM color 3b
echo Installing SQL 2014 Express %str%
echo.
%extractdir%\SETUP.EXE /ConfigurationFile=%ConfigurationFile% /IAcceptSQLServerLicenseTerms
echo.
echo Installation Completed,
echo Please refer to the log here "C:\Program Files\Microsoft SQL Server\120\Setup Bootstrap\Log\Summary.txt"
echo Restarting machine to complete installation, please run the installation again after restart and choose %partition% as the installation partition
echo.
pause
shutdown /r

:restore
REM Prompt user for SQL Server instance name and backup file path
echo.
xcopy /y .\Tradeplus.bak %homedir%\BACKUP\
echo Restoring database TRUEBOOK to the new instance
echo.
REM echo Please copy the backup file to the following path %homedir%\BACKUP\
pause

set dbname=Truebook

echo DECLARE @BackupFile NVARCHAR(255) = '%homedir%\BACKUP\Tradeplus.bak' >%temp%\restore.sql
echo DECLARE @DataFolder NVARCHAR(255) = CAST(SERVERPROPERTY('InstanceDefaultDataPath') AS NVARCHAR(255)) >>%temp%\restore.sql
echo DECLARE @RestoreSQL NVARCHAR(MAX)>>%temp%\restore.sql
echo /**/>>%temp%\restore.sql
echo DECLARE @LogicalNameData NVARCHAR(128),>>%temp%\restore.sql
echo         @LogicalNameLog NVARCHAR(128),>>%temp%\restore.sql
echo         @PhysicalNameData NVARCHAR(260),>>%temp%\restore.sql
echo         @PhysicalNameLog NVARCHAR(260)>>%temp%\restore.sql
echo /**/>>%temp%\restore.sql
echo -- Create temp table to store file list information>>%temp%\restore.sql
echo IF OBJECT_ID('tempdb..#FileList') IS NOT NULL>>%temp%\restore.sql
echo 	DROP TABLE #FileList;>>%temp%\restore.sql
echo CREATE TABLE #FileList (>>%temp%\restore.sql
echo     LogicalName NVARCHAR(128),>>%temp%\restore.sql
echo     PhysicalName NVARCHAR(260),>>%temp%\restore.sql
echo     FileType CHAR(1),>>%temp%\restore.sql
echo     FileGroupName NVARCHAR(128),>>%temp%\restore.sql
echo     Size NUMERIC(20,0),>>%temp%\restore.sql
echo     MaxSize NUMERIC(20,0),>>%temp%\restore.sql
echo     FileId BIGINT,>>%temp%\restore.sql
echo     CreateLSN NUMERIC(25,0),>>%temp%\restore.sql
echo     DropLSN NUMERIC(25,0),>>%temp%\restore.sql
echo     UniqueId UNIQUEIDENTIFIER,>>%temp%\restore.sql
echo     ReadOnlyLSN NUMERIC(25,0),>>%temp%\restore.sql
echo     ReadWriteLSN NUMERIC(25,0),>>%temp%\restore.sql
echo     BackupSizeInBytes BIGINT,>>%temp%\restore.sql
echo     SourceBlockSize INT,>>%temp%\restore.sql
echo     FileGroupId INT,>>%temp%\restore.sql
echo     LogGroupGUID UNIQUEIDENTIFIER,>>%temp%\restore.sql
echo     DifferentialBaseLSN NUMERIC(25,0),>>%temp%\restore.sql
echo     DifferentialBaseGUID UNIQUEIDENTIFIER,>>%temp%\restore.sql
echo     IsReadOnly BIT,>>%temp%\restore.sql
echo     IsPresent BIT,>>%temp%\restore.sql
echo     TDEThumbprint VARBINARY(32)>>%temp%\restore.sql
echo )>>%temp%\restore.sql
echo /**/>>%temp%\restore.sql
echo SET @RestoreSQL = 'RESTORE FILELISTONLY FROM DISK = ''' + @BackupFile + '''>>%temp%\restore.sql
echo WITH FILE = 1'>>%temp%\restore.sql
echo /**/>>%temp%\restore.sql
echo /**/>>%temp%\restore.sql
echo -- Get logical and physical file names from backup file>>%temp%\restore.sql
echo INSERT INTO #FileList>>%temp%\restore.sql
echo EXEC(@RestoreSQL)>>%temp%\restore.sql
echo /**/>>%temp%\restore.sql
echo SET @LogicalNameData = (SELECT TOP 1 LogicalName FROM #FileList WHERE FileType = 'D')>>%temp%\restore.sql
echo SET @LogicalNameLog = (SELECT TOP 1 LogicalName FROM #FileList WHERE FileType = 'L')>>%temp%\restore.sql
echo SET @PhysicalNameData = @DataFolder + @LogicalNameData + '.mdf'>>%temp%\restore.sql
echo SET @PhysicalNameLog = @DataFolder + @LogicalNameLog + '.ldf'>>%temp%\restore.sql
echo /**/>>%temp%\restore.sql
echo -- Restore database using the retrieved file names>>%temp%\restore.sql
echo RESTORE DATABASE %dbname%>>%temp%\restore.sql
echo FROM DISK = @BackupFile>>%temp%\restore.sql
echo WITH MOVE @LogicalNameData TO @PhysicalNameData,>>%temp%\restore.sql
echo      MOVE @LogicalNameLog TO @PhysicalNameLog,>>%temp%\restore.sql
echo      REPLACE>>%temp%\restore.sql

SQLCMD -S localhost\%instancename% -U sa -P %SA_PASSWORD% -Q "CREATE DATABASE %dbname%"
SQLCMD -S localhost\%instancename% -U sa -P %SA_PASSWORD% -i %temp%\restore.sql

pause
REM Display message indicating restore operation is complete
echo.
echo Database [%dbname%] has been restored from backup file %backuppath%.

echo.
echo Configuring ODBC for %instancename%
REM Prompt user for DSN name, server name, database name, and authentication details
set dsnname=%instancename%
set servername=localhost\%instancename%
set dbname=%dbname%
set auth=1
set osversion=%str%
REM Enter the authentication method (1 for SQL authentication, 2 for Windows authentication):
if %auth% == 1 (
    set username=sa
)


REM Determine the OS architecture and set the Registry path accordingly
if /i "%osversion%"=="x64" (
	set "regpath=HKLM\SOFTWARE\Wow6432Node\ODBC\ODBC.INI\%dsnname%"
	set "odbcpath=HKLM\SOFTWARE\Wow6432Node\ODBC\ODBC.INI\ODBC Data Sources"
) else (
    set "regpath=HKLM\SOFTWARE\ODBC\ODBC.INI\%dsnname%"
	set "odbcpath=HKLM\SOFTWARE\ODBC\ODBC.INI\ODBC Data Sources"
)

REM echo %odbcpath%
REM echo %regpath%
REM echo %dsnname%
REM echo %odbcpath%

REM Create the ODBC data source using the specified parameters
    reg add "%regpath%" /v "Driver" /t REG_SZ /d "C:\WINDOWS\system32\SQLSRV32.dll" /f>nul
    reg add "%regpath%" /v "Server" /t REG_SZ /d "%servername%" /f>nul
    reg add "%regpath%" /v "Database" /t REG_SZ /d "%dbname%" /f>nul
    reg add "%regpath%" /v "LastUser" /t REG_SZ /d "%username%" /f>nul
	reg add "%odbcpath%" /v "%dsnname%" /t REG_SZ /d "SQL Server" /f>nul


if /i "%osversion%"=="x64" (
    set "regpath=HKLM\SOFTWARE\ODBC\ODBC.INI\%dsnname%"
	set "odbcpath=HKLM\SOFTWARE\ODBC\ODBC.INI\ODBC Data Sources"
REM Create extra ODBC data source for x64
    reg add "%regpath%" /v "Driver" /t REG_SZ /d "C:\WINDOWS\system32\SQLSRV32.dll" /f>nul
    reg add "%regpath%" /v "Server" /t REG_SZ /d "%servername%" /f>nul
    reg add "%regpath%" /v "Database" /t REG_SZ /d "%dbname%" /f>nul
    reg add "%regpath%" /v "LastUser" /t REG_SZ /d "%username%" /f>nul
	reg add "%odbcpath%" /v "%dsnname%" /t REG_SZ /d "SQL Server" /f>nul
)

    set regpath=HKLM\SOFTWARE\ODBC\ODBC.INI\%dsnname%
	set odbcpath=HKLM\SOFTWARE\ODBC\ODBC.INI\
REM Display message indicating DSN creation is complete
echo.
echo DSN [%dsnname%] has been created.

pause

echo.
echo Copying setup files to installaion directory
xcopy /y .\*.exe %installdir%\ 
powershell -command "Expand-Archive -Force -Path '%cd%\Crystal32fix.zip' -DestinationPath '%installdir%\'"
powershell -command "Expand-Archive -Force -Path '%cd%\reports.zip' -DestinationPath '%homedir%\REPORTS\'"

REM expand -r Crystal32fix.zip %homedir%\SETUP\

echo.
echo Installing Tradeplus
set tradeplus=%installdir%\TradeplusSetup.exe
%tradeplus%
set tradeplus=%installdir%\Tradeplus.exe
%tradeplus%
echo Tradeplus installed successfully
echo.
echo Installing Crystal32fix
echo crystal is %installdir%\Crystal32fix\setup.exe
set crystal=%installdir%\Crystal32fix\setup.exe
%crystal%
echo Crystal32fix installed successfully
echo.
REM pause


REM  Delete temporary files
REM color 3b
echo Deleting leftover installation files from %extractdir%
echo.
rem del /f /q %extractdir%\*

rem rmdir /s /q %extractdir%
rem del /f /q %installdir%\*.ini
echo.
echo Have a great day ;)
echo.
pause
endlocal

:exit