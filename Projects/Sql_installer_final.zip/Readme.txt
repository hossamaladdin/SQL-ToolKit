SQL 2014 Silent Installer
By Hossam Alaadin
=======================================================================
About the author:
Hossam Alaaddin | SQL Developer and DBA
hossam.alaaddin@gmail.com
www.linkedin.com/in/hossamaladdin/
github.com/hossamaladdin
=======================================================================
About the script:
The script included here installs SQL Server 2014 Express Edition in silent mode with pre defined parameters as shown in the image "How to config.jpeg", you can configure the installation as needed easily by modifying the values inside the files.

How to run:
Simply right click on the file "SQL_2014_Express_SilentInstaller.bat" and choose "Run as administrator", then you will be prompted to run the installer with priviliges.

-The installer prompts the user to enter the drive letter in which installation files are deployed
-Then it will continue automatically to install SQL Server 2014 Express Edition in the background, the installer checks for OS architecture (x64 or x86) and downloads the correct version for it and then it starts the installation process
-After the installation completes, a prompt will notify the user with the location of the log file to check for any errors happened during the installation

Salam!
If you have any issues running the file please contact me at the channels mentioned above!