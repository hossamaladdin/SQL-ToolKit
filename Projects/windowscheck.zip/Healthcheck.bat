@echo off
del /q "C:\temp\wgrafana2\healthcheck_*"

powershell.exe -ExecutionPolicy Bypass -File "C:\temp\wgrafana2\healthchk.ps1"

(
	echo cd /userdata/WindowsHealthCheck/input/
	echo lcd C:\temp\wgrafana2\
	echo mput healthcheck_*
	echo quit
)|C:\temp\wgrafana2\psftp -i C:\temp\wgrafana2\PRIV.ppk <SFTP_USER>@<SFTP_HOST>