SET NOCOUNT ON;
SELECT
   r.session_id,
   s.host_name,                  -- Machine running the query
   s.login_name AS user_name,     -- User executing the query
   DB_NAME(r.database_id) AS database_name,  -- Database being queried
   r.status,
   r.start_time,
   r.total_elapsed_time / 1000 AS elapsed_time_sec,  -- Execution time in seconds
   r.cpu_time / 1000 AS cpu_time_sec,
   r.logical_reads,
   r.reads,
   r.writes,
   r.blocking_session_id,         -- Blocking session if any
   t.text AS query_text,          -- SQL statement being executed
   r.command                      -- Type of SQL command
FROM sys.dm_exec_requests r
CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) t
LEFT JOIN sys.dm_exec_sessions s ON r.session_id = s.session_id
WHERE r.status NOT IN ('background', 'sleeping')  -- Ignore idle processes
AND r.total_elapsed_time > 30000  -- Show queries running longer than 30 sec
ORDER BY r.total_elapsed_time DESC;