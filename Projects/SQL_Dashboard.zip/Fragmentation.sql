SET NOCOUNT ON;
DECLARE @sql NVARCHAR(MAX) = ''
--DECLARE @filePath NVARCHAR(500) = 'C:\SQL_Exports\TopTableSizes.csv'
SELECT @sql = @sql +
'USE [' + name + '];
SELECT
   s.host_name server_name, 
  '''+name+''' AS database_name,  -- Database name  
   OBJECT_NAME(ps.object_id, ps.database_id) AS table_name, 
   i.name AS index_name,
   ps.index_id,  
   ps.avg_fragmentation_in_percent,
   ps.avg_page_space_used_in_percent,
   ps.page_count
   --,ps.record_count
FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL, ''LIMITED'') ps  
JOIN sys.indexes i ON ps.object_id = i.object_id AND ps.index_id = i.index_id  
JOIN sys.dm_exec_sessions s ON s.session_id = @@SPID  -- Get host name  
WHERE ps.index_id > 0  -- Ignore heap tables
	AND ps.database_id > 4
	AND ps.avg_fragmentation_in_percent >=1
ORDER BY ps.avg_fragmentation_in_percent DESC;' + CHAR(13)
FROM sys.databases
WHERE database_id > 4 -- Exclude system databases
	AND state_desc <> 'OFFLINE';
-- Execute query and export result to CSV
EXEC sp_executesql @sql;
