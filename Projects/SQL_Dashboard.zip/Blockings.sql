SET NOCOUNT ON;
SELECT
   r.session_id,
   s.host_process_id,           -- Process ID of the client application
   s.client_interface_name,     -- SQL Client Library (e.g., .NET SqlClient, JDBC)
   s.login_name AS user_name,   -- User executing the query
   s.program_name,              -- Application running the query
   s.host_name,                 -- Client machine name
   r.status,
   r.start_time,
   r.cpu_time,
   r.total_elapsed_time / 1000 AS elapsed_time_sec,
   r.logical_reads,
   r.reads,
   r.writes,
   r.blocking_session_id,
   b.session_id AS blocked_session_id,  
   b.wait_type,
   b.wait_time / 1000 AS wait_time_sec,
   b.wait_resource,
   DB_NAME(r.database_id) AS database_name,
   t.text AS query_text,
   r.command
FROM sys.dm_exec_requests r
CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) t
LEFT JOIN sys.dm_exec_sessions s ON r.session_id = s.session_id  -- Get user, program, and client details
LEFT JOIN sys.dm_exec_requests b ON r.session_id = b.blocking_session_id  
WHERE r.status NOT IN ('background', 'sleeping')
AND r.total_elapsed_time > 30000  -- Show queries running longer than 30 sec
ORDER BY r.total_elapsed_time DESC;