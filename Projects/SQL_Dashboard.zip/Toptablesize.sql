SET NOCOUNT ON;
DECLARE @sql NVARCHAR(MAX) = ''
--DECLARE @filePath NVARCHAR(500) = 'C:\SQL_Exports\TopTableSizes.csv'
SELECT @sql = @sql +
'USE [' + name + '];
SELECT
   ''' + name + ''' AS database_name,
   SCHEMA_NAME(o.schema_id) AS schema_name,
   o.name AS table_name,
   SUM(p.rows) AS row_count,
   SUM(a.total_pages) * 8 / 1024 AS total_size_MB,
   SUM(a.used_pages) * 8 / 1024 AS used_size_MB,
   (SUM(a.total_pages) - SUM(a.used_pages)) * 8 / 1024 AS unused_size_MB
FROM sys.tables o
JOIN sys.partitions p ON o.object_id = p.object_id AND p.index_id IN (0, 1)
JOIN sys.allocation_units a ON p.partition_id = a.container_id
GROUP BY o.object_id, o.name, o.schema_id
ORDER BY total_size_MB DESC;' + CHAR(13)
FROM sys.databases
WHERE database_id > 4
	AND state_desc <> 'OFFLINE'; -- Exclude system databases
-- Execute query and export result to CSV
EXEC sp_executesql @sql;