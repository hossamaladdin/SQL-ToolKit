﻿$timer = [int](Get-Date -uFormat %s)

$queries = @(
    @{ File = "Fragmentation"; Sql = "Fragmentation.sql" },
    @{ File = "ToptableSize";  Sql = "Toptablesize.sql" },
    @{ File = "Blockings";     Sql = "Blockings.sql" },
    @{ File = "Longrun";       Sql = "Longrun.sql" }
)

foreach ($q in $queries) {
    $outFile = "D:\SQLGrafana\healthcheck_$($q.File)`_$timer.csv"

    $output = sqlcmd -S $env:computername `
                     -U Grafana_User `
                     -P 12345 `
                     -W -s"," -h1 `
                     -i "D:\SQLGrafana\$($q.Sql)"

    $seenHeader = $false
    $cleaned = foreach ($line in $output) {
        # Skip separator lines
        if ($line -match '^[-,]+$') { continue }

        # Updated header pattern to include session_id and other common first columns
        if ($line -match '^(database_name|server_name|host_name|schema_name|session_id),') {
            if (-not $seenHeader) {
                $seenHeader = $true
                $line
            }
            continue
        }

        $line
    }

    $cleaned | Out-File $outFile -Encoding utf8
}