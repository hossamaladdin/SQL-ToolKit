-- -----------------------------------------------------------------------
-- Q10. What is the recovery model of each database?
-- Q18. What are the database compatibility levels?
-- Q19. Are any databases encrypted using TDE?
-- (plus: is each database in an Availability Group, and which one)
-- -----------------------------------------------------------------------
IF CAST(SERVERPROPERTY('IsHadrEnabled') AS int) = 1
BEGIN
    SELECT
        d.name AS DatabaseName,
        d.state_desc,
        d.recovery_model_desc,
        d.compatibility_level,
        d.user_access_desc,
        d.is_read_only,
        d.page_verify_option_desc,
        d.is_encrypted,
        dek.encryption_state,
        CASE dek.encryption_state
            WHEN 0 THEN 'No database encryption key'
            WHEN 1 THEN 'Unencrypted'
            WHEN 2 THEN 'Encryption in progress'
            WHEN 3 THEN 'Encrypted'
            WHEN 4 THEN 'Key change in progress'
            WHEN 5 THEN 'Decryption in progress'
            WHEN 6 THEN 'Protection change in progress'
        END AS EncryptionStateDescription,
        dek.encryptor_type,
        CASE WHEN ag.name IS NOT NULL THEN 'YES' ELSE 'NO' END AS Is_In_AG,
        ag.name AS AG_Name,
        drs.is_local,
        ars.role_desc AS AG_Role_OnThisReplica,
        drs.synchronization_state_desc
    FROM sys.databases AS d
    LEFT JOIN sys.dm_database_encryption_keys AS dek
        ON d.database_id = dek.database_id
    LEFT JOIN sys.dm_hadr_database_replica_states AS drs
        ON d.database_id = drs.database_id AND drs.is_local = 1
    LEFT JOIN sys.availability_groups AS ag
        ON drs.group_id = ag.group_id
    LEFT JOIN sys.dm_hadr_availability_replica_states AS ars
        ON drs.replica_id = ars.replica_id AND ars.is_local = 1
    ORDER BY d.name;
END
ELSE
BEGIN
    -- Always On not enabled on this instance: no AG membership possible.
    SELECT
        d.name AS DatabaseName,
        d.state_desc,
        d.recovery_model_desc,
        d.compatibility_level,
        d.user_access_desc,
        d.is_read_only,
        d.page_verify_option_desc,
        d.is_encrypted,
        dek.encryption_state,
        CASE dek.encryption_state
            WHEN 0 THEN 'No database encryption key'
            WHEN 1 THEN 'Unencrypted'
            WHEN 2 THEN 'Encryption in progress'
            WHEN 3 THEN 'Encrypted'
            WHEN 4 THEN 'Key change in progress'
            WHEN 5 THEN 'Decryption in progress'
            WHEN 6 THEN 'Protection change in progress'
        END AS EncryptionStateDescription,
        dek.encryptor_type,
        'NO' AS Is_In_AG,
        CAST(NULL AS sysname) AS AG_Name,
        CAST(NULL AS bit) AS is_local,
        CAST(NULL AS nvarchar(60)) AS AG_Role_OnThisReplica,
        CAST(NULL AS nvarchar(60)) AS synchronization_state_desc
    FROM sys.databases AS d
    LEFT JOIN sys.dm_database_encryption_keys AS dek
        ON d.database_id = dek.database_id
    ORDER BY d.name;
END

-- -----------------------------------------------------------------------
-- Q11. What are current database sizes, including data and transaction
--      log sizes?
-- -----------------------------------------------------------------------
SELECT
    DB_NAME(database_id) AS DatabaseName,
    CAST(SUM(CASE WHEN type_desc = 'ROWS' THEN size ELSE 0 END) * 8.0 / 1024 AS decimal(18,2)) AS DataSizeMB,
    CAST(SUM(CASE WHEN type_desc = 'LOG'  THEN size ELSE 0 END) * 8.0 / 1024 AS decimal(18,2)) AS LogSizeMB,
    CAST(SUM(size) * 8.0 / 1024 AS decimal(18,2)) AS TotalSizeMB,
    CAST(SUM(size) * 8.0 / 1024 / 1024 AS decimal(18,2)) AS TotalSizeGB
FROM sys.master_files
GROUP BY database_id
ORDER BY TotalSizeMB DESC;

-- File-level detail:
SELECT
    DB_NAME(database_id) AS DatabaseName,
    type_desc,
    name AS LogicalFileName,
    physical_name,
    CAST(size * 8.0 / 1024 AS decimal(18,2)) AS SizeMB,
    CASE
        WHEN max_size = -1 THEN 'UNLIMITED'
        ELSE CAST(CAST(max_size * 8.0 / 1024 AS decimal(18,2)) AS varchar(50)) + ' MB'
    END AS MaxSize,
    CASE
        WHEN is_percent_growth = 1 THEN CAST(growth AS varchar(20)) + ' %'
        ELSE CAST(CAST(growth * 8.0 / 1024 AS decimal(18,2)) AS varchar(50)) + ' MB'
    END AS GrowthSetting
FROM sys.master_files
ORDER BY DB_NAME(database_id), type_desc, file_id;

-- -----------------------------------------------------------------------
-- Q13. What is the current backup strategy (Full, Differential,
--      Transaction Log), including backup frequency and retention?
-- -----------------------------------------------------------------------
-- Last successful backup by type:
WITH B AS
(
    SELECT
        database_name,
        type,
        backup_start_date,
        backup_finish_date,
        backup_size,
        compressed_backup_size,
        ROW_NUMBER() OVER
        (
            PARTITION BY database_name, type
            ORDER BY backup_finish_date DESC
        ) AS rn
    FROM msdb.dbo.backupset
)
SELECT
    database_name,
    CASE type WHEN 'D' THEN 'FULL'
              WHEN 'I' THEN 'DIFFERENTIAL'
              WHEN 'L' THEN 'LOG'
              ELSE type END AS BackupType,
    backup_start_date,
    backup_finish_date,
    CAST(backup_size / 1073741824.0 AS decimal(18,2)) AS BackupSizeGB,
    CAST(compressed_backup_size / 1073741824.0 AS decimal(18,2)) AS CompressedBackupSizeGB
FROM B
WHERE rn = 1
ORDER BY database_name, BackupType;

-- Backup history for the last 30 days to determine actual frequency/pattern:
SELECT
    bs.database_name,
    CASE bs.type WHEN 'D' THEN 'FULL'
                 WHEN 'I' THEN 'DIFFERENTIAL'
                 WHEN 'L' THEN 'LOG'
                 ELSE bs.type END AS BackupType,
    bs.backup_start_date,
    bs.backup_finish_date,
    bmf.physical_device_name,
    bs.is_copy_only,
    bs.is_snapshot,
    CAST(bs.backup_size / 1073741824.0 AS decimal(18,2)) AS BackupSizeGB
FROM msdb.dbo.backupset AS bs
LEFT JOIN msdb.dbo.backupmediafamily AS bmf
    ON bs.media_set_id = bmf.media_set_id
WHERE bs.backup_start_date >= DATEADD(DAY,-30,GETDATE())
ORDER BY bs.database_name, bs.backup_start_date DESC;

-- NOTE: retention cannot be reliably derived only from backupset history.
-- Confirm retention from the backup product/policy (NetBackup, Commvault,
-- Veeam, etc.) and from SQL Agent/Maintenance Plan cleanup settings.
