SET NOCOUNT ON;

-- Report Server catalog (SSRS native mode OR Power BI Report Server -
-- both share the same catalog schema; T-SQL cannot tell them apart, see
-- NOTE below).
DECLARE @RSCatalogCount int = 0;
DECLARE @DbName sysname, @Sql nvarchar(max), @found bit;
DECLARE db_cursor CURSOR LOCAL FAST_FORWARD FOR
    SELECT name FROM sys.databases WHERE state_desc = 'ONLINE';
OPEN db_cursor;
FETCH NEXT FROM db_cursor INTO @DbName;
WHILE @@FETCH_STATUS = 0
BEGIN
    SET @found = 0;
    SET @Sql = N'
    IF EXISTS (SELECT 1 FROM ' + QUOTENAME(@DbName) + N'.sys.tables WHERE name = ''Catalog'')
       AND EXISTS (SELECT 1 FROM ' + QUOTENAME(@DbName) + N'.sys.tables WHERE name = ''Keys'')
       AND EXISTS (SELECT 1 FROM ' + QUOTENAME(@DbName) + N'.sys.tables WHERE name = ''ConfigurationInfo'')
        SET @found = 1;';
    EXEC sp_executesql @Sql, N'@found bit OUTPUT', @found = @found OUTPUT;
    IF @found = 1 SET @RSCatalogCount = @RSCatalogCount + 1;
    FETCH NEXT FROM db_cursor INTO @DbName;
END
CLOSE db_cursor;
DEALLOCATE db_cursor;

DECLARE @LegacySSISCount int = CASE WHEN EXISTS (SELECT 1 FROM sys.tables WHERE name = 'sysssispackages') THEN (SELECT COUNT(*) FROM msdb.dbo.sysssispackages) ELSE 0 END;
DECLARE @SSISDBExists bit = CASE WHEN EXISTS (SELECT 1 FROM sys.databases WHERE name = 'SSISDB') THEN 1 ELSE 0 END;
DECLARE @SSISDBProjectCount int = 0;
IF @SSISDBExists = 1
    EXEC sp_executesql N'SELECT @cnt = COUNT(*) FROM SSISDB.catalog.projects', N'@cnt int OUTPUT', @cnt = @SSISDBProjectCount OUTPUT;

SELECT
    CASE WHEN @RSCatalogCount > 0 THEN 'YES' ELSE 'NO' END AS ReportServer_Catalog_Present,
    @RSCatalogCount AS ReportServer_CatalogDatabaseCount,
    CASE WHEN @LegacySSISCount > 0 THEN 'YES' ELSE 'NO' END AS Legacy_SSIS_PackageStore_InUse,
    @LegacySSISCount AS Legacy_SSIS_PackageCount,
    CASE WHEN @SSISDBExists = 1 THEN 'YES' ELSE 'NO' END AS SSISDB_Catalog_Present,
    @SSISDBProjectCount AS SSISDB_ProjectCount;

-- NOTE:
-- A YES on ReportServer_Catalog_Present means this database is a Reporting
-- Services catalog (ReportServer-style DB). SSRS and Power BI Report
-- Server share the same catalog schema, so T-SQL cannot reliably
-- distinguish one from the other. Confirm the actual product and the
-- report server instance it belongs to from the Windows service
-- DisplayName (zip file 07, PowerShell) or rsreportserver.config on the
-- report server machine. The SSRS encryption key itself cannot be read
-- via T-SQL - back it up with rskeymgmt.exe BEFORE migration regardless.
--
-- Packages deployed directly to the file system (.dtsx on disk, run via a
-- SQL Agent CmdExec/File System step calling dtexec.exe with /F) are
-- invisible to both SSIS checks above - cross-check the zip's Q09
-- job-step dump (file 03) for any CmdExec steps referencing dtexec.exe.
--
-- If you need full package/project/folder-level detail for a YES here
-- (names, owners, deployment dates, environment variables), ask and a
-- drill-down script can be added back for that specific database.
