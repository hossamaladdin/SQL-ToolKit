-- -----------------------------------------------------------------------
-- Q01. What is the current SQL Server version, edition, and build/CU level?
-- -----------------------------------------------------------------------
SELECT
    @@SERVERNAME AS ServerName,
    SERVERPROPERTY('MachineName') AS MachineName,
    SERVERPROPERTY('InstanceName') AS InstanceName,
    SERVERPROPERTY('ProductVersion') AS ProductVersion,
    SERVERPROPERTY('ProductLevel') AS ProductLevel,
    SERVERPROPERTY('ProductUpdateLevel') AS ProductUpdateLevel,
    SERVERPROPERTY('ProductUpdateReference') AS ProductUpdateReference,
    SERVERPROPERTY('Edition') AS Edition,
    SERVERPROPERTY('EngineEdition') AS EngineEdition,
    @@VERSION AS FullVersion;
-- NOTE: ProductUpdateLevel/ProductUpdateReference may be NULL on older SQL builds.

-- -----------------------------------------------------------------------
-- Q02. Total server memory, and configured SQL Server maximum memory
--      FIX: total_physical_memory_kb (was invalid: physical_memory_kb)
-- -----------------------------------------------------------------------
SELECT
    CAST(total_physical_memory_kb / 1024.0 AS decimal(18,2)) AS TotalPhysicalMemoryMB,
    CAST(available_physical_memory_kb / 1024.0 AS decimal(18,2)) AS AvailablePhysicalMemoryMB,
    system_memory_state_desc
FROM sys.dm_os_sys_memory;

SELECT
    name,
    value AS ConfiguredValue,
    value_in_use AS ValueInUse
FROM sys.configurations
WHERE name IN ('min server memory (MB)', 'max server memory (MB)');

-- -----------------------------------------------------------------------
-- Q03. How many CPU cores are allocated to the SQL Server?
--      FIX: version-gated - socket_count/cores_per_socket/numa_node_count
--      require SQL Server 2016+ (confirmed: SQL2012 does not have them).
-- -----------------------------------------------------------------------
-- socket_count/cores_per_socket/numa_node_count: guarded via COL_LENGTH
-- (not a major-version number) so this stays correct regardless of exact
-- CU/SP backport history.
IF COL_LENGTH('sys.dm_os_sys_info', 'socket_count') IS NOT NULL
BEGIN
    EXEC('
    SELECT
        cpu_count AS LogicalCPUCountVisibleToSQL,
        hyperthread_ratio,
        socket_count,
        cores_per_socket,
        numa_node_count,
        scheduler_count
    FROM sys.dm_os_sys_info;');
END
ELSE
BEGIN
    SELECT
        cpu_count AS LogicalCPUCountVisibleToSQL,
        hyperthread_ratio,
        scheduler_count
    FROM sys.dm_os_sys_info;
    SELECT 'socket_count/cores_per_socket/numa_node_count are not available on this SQL Server version/patch level. Confirm core/socket/NUMA layout with the VM/hypervisor/OCI infrastructure team instead.' AS Note;
END
-- NOTE: cpu_count is the number of logical CPUs visible to SQL Server.
-- Licensing/core allocation should also be confirmed with the
-- VM/hypervisor/OCI infrastructure team.

-- -----------------------------------------------------------------------
-- Q04. How are SQL Server data, log, and TempDB files distributed across
--      storage?
-- -----------------------------------------------------------------------
SELECT
    DB_NAME(mf.database_id) AS DatabaseName,
    mf.file_id,
    mf.type_desc AS FileType,
    mf.name AS LogicalFileName,
    mf.physical_name,
    CAST(mf.size * 8.0 / 1024 AS decimal(18,2)) AS FileSizeMB,
    vs.volume_mount_point,
    vs.file_system_type,
    CAST(vs.total_bytes / 1073741824.0 AS decimal(18,2)) AS VolumeTotalGB,
    CAST(vs.available_bytes / 1073741824.0 AS decimal(18,2)) AS VolumeFreeGB
FROM sys.master_files AS mf
CROSS APPLY sys.dm_os_volume_stats(mf.database_id, mf.file_id) AS vs
ORDER BY DB_NAME(mf.database_id), mf.type_desc, mf.file_id;

-- -----------------------------------------------------------------------
-- Q05. Which SQL Server services are installed, and which are in use?
-- Q06. What service accounts are used by SQL Server and SQL Server Agent?
-- -----------------------------------------------------------------------
-- instant_file_initialization_enabled was backported into sys.dm_server_services
-- via specific CUs/SPs (SQL2012 SP4, SQL2014 SP2, SQL2016 SP1+), not tied to
-- major version - an instance on an older patch level will error with
-- "Invalid column name" if this is selected directly. Guarded via COL_LENGTH.
IF COL_LENGTH('sys.dm_server_services', 'instant_file_initialization_enabled') IS NOT NULL
BEGIN
    EXEC('
    SELECT
        servicename,
        startup_type_desc,
        status_desc,
        service_account,
        filename,
        is_clustered,
        cluster_nodename,
        instant_file_initialization_enabled
    FROM sys.dm_server_services
    ORDER BY servicename;');
END
ELSE
BEGIN
    SELECT
        servicename,
        startup_type_desc,
        status_desc,
        service_account,
        filename,
        is_clustered,
        cluster_nodename,
        CAST(NULL AS char(1)) AS instant_file_initialization_enabled
    FROM sys.dm_server_services
    ORDER BY servicename;
END
-- NOTE: this DMV covers SQL-related services visible to SQL Server. For a
-- complete Windows service inventory, also run the zip's PowerShell file
-- (07_Windows_PowerShell_Inventory.txt). If instant_file_initialization_enabled
-- shows NULL, the instance's CU/SP level doesn't report it - check manually
-- (SQL Server error log on startup, or the "Perform Volume Maintenance
-- Tasks" policy for the service account).

-- -----------------------------------------------------------------------
-- Q07. What TCP port is configured for each SQL Server instance?
-- -----------------------------------------------------------------------
-- Current SQL connection:
SELECT
    @@SERVERNAME AS ServerName,
    local_net_address,
    local_tcp_port,
    net_transport,
    protocol_type,
    encrypt_option,
    auth_scheme
FROM sys.dm_exec_connections
WHERE session_id = @@SPID;

-- Listener state / port from SQL error log (useful if needed):
EXEC master.dbo.xp_readerrorlog 0, 1, N'Server is listening on';
-- NOTE: for dynamic ports or all IP-specific TCP settings, use SQL Server
-- Configuration Manager or the PowerShell/registry check in the zip's
-- Windows script.

-- -----------------------------------------------------------------------
-- Q17. What are the Windows Server versions of the current SQL Server nodes?
-- -----------------------------------------------------------------------
SELECT
    windows_release,
    windows_service_pack_level,
    windows_sku,
    os_language_version
FROM sys.dm_os_windows_info;

-- -----------------------------------------------------------------------
-- (Re-titled - unlabeled in the original zip file) MAXDOP / cost threshold
-- for parallelism
-- -----------------------------------------------------------------------
SELECT
    name,
    value AS ConfiguredValue,
    value_in_use AS CurrentValue
FROM sys.configurations
WHERE name IN (
    'max degree of parallelism',
    'cost threshold for parallelism'
);

-- -----------------------------------------------------------------------
-- (Re-titled - unlabeled in the original zip file) Full SQL Server
-- configuration dump
-- -----------------------------------------------------------------------
SELECT
    name,
    value AS ConfiguredValue,
    value_in_use AS RunningValue,
    is_dynamic,
    is_advanced
FROM sys.configurations
ORDER BY name;
-- NOTE: Windows cumulative update / KB patch level is collected by
-- PowerShell because SQL Server DMVs do not provide the complete OS
-- hotfix inventory.

-- -----------------------------------------------------------------------
-- SUPPLEMENTAL (not in the zip or original Q-list): live CPU utilization
-- and actual SQL Server memory-in-use snapshot, for OCI compute/memory
-- right-sizing. Q02/Q03 above are static configuration only; this is a
-- point-in-time real usage snapshot - re-run at a representative busy
-- time, a single sample is not sufficient for sizing decisions.
-- -----------------------------------------------------------------------
SET QUOTED_IDENTIFIER ON;
;WITH RingBufferCPU AS
(
    SELECT TOP 1
        CAST(record AS XML) AS record_data
    FROM sys.dm_os_ring_buffers
    WHERE ring_buffer_type = N'RING_BUFFER_SCHEDULER_MONITOR'
    ORDER BY timestamp DESC
)
SELECT
    CPU.value('(./SystemIdle)[1]', 'int') AS SystemIdle_Perc,
    100 - CPU.value('(./SystemIdle)[1]', 'int') AS TotalCPU_Used_Perc,
    CPU.value('(./ProcessUtilization)[1]', 'int') AS SQL_CPU_Used_Perc,
    CAST(mem.physical_memory_in_use_kb / 1048576.0 AS DECIMAL(13,2)) AS SQL_Memory_Used_GB,
    CAST(mem.physical_memory_in_use_kb * 1.0 / osmem.total_physical_memory_kb * 100 AS DECIMAL(13,2)) AS SQL_Memory_Used_Perc_OfTotal,
    CAST(mem.virtual_address_space_committed_kb / 1048576.0 AS DECIMAL(13,2)) AS SQL_Memory_Committed_GB,
    CAST(osmem.total_physical_memory_kb / 1048576.0 AS DECIMAL(13,2)) AS Server_Total_Memory_GB,
    CAST(osmem.available_physical_memory_kb / 1048576.0 AS DECIMAL(13,2)) AS Server_Available_Memory_GB,
    GETDATE() AS SampleTakenAt
FROM RingBufferCPU AS rb
CROSS APPLY rb.record_data.nodes('/Record/SchedulerMonitorEvent/SystemHealth') AS T(CPU)
CROSS JOIN sys.dm_os_process_memory AS mem
CROSS JOIN sys.dm_os_sys_memory AS osmem;
-- NOTE: SystemIdle/ProcessUtilization are smoothed values refreshed about
-- once per minute by SQL Server - this is a recent-minute average, not an
-- instantaneous reading.
