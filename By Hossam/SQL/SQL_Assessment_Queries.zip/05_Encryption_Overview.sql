SET NOCOUNT ON;
DECLARE @MajorVersion int = CAST(SERVERPROPERTY('ProductMajorVersion') AS int);

-- -----------------------------------------------------------------------
-- Silent computation pass - populates temp tables / counters used by both
-- the summary row and the detail sections below. Nothing is displayed
-- until the "SECTION 0: SUMMARY" block.
-- -----------------------------------------------------------------------

-- TDE
DECLARE @TDE_Count int = (SELECT COUNT(*) FROM sys.databases AS d JOIN sys.dm_database_encryption_keys AS dek ON d.database_id = dek.database_id WHERE dek.encryption_state = 3);

-- Certificates in master + EKM providers
DECLARE @CertMaster_Count int = (SELECT COUNT(*) FROM sys.certificates WHERE name NOT LIKE '##%##');
DECLARE @EKM_Count int = (SELECT COUNT(*) FROM sys.cryptographic_providers);
DECLARE @AsymKeyMaster_Count int = (SELECT COUNT(*) FROM sys.asymmetric_keys WHERE name NOT LIKE '##%##');

-- Database Master Key presence + certificates-in-user-DBs (loop once, store both)
IF OBJECT_ID('tempdb..#DMKPresence') IS NOT NULL DROP TABLE #DMKPresence;
CREATE TABLE #DMKPresence (DatabaseName sysname, KeyAlgorithm nvarchar(60), KeyLength int);

IF OBJECT_ID('tempdb..#UserCerts') IS NOT NULL DROP TABLE #UserCerts;
CREATE TABLE #UserCerts (DatabaseName sysname, CertificateName sysname, IssuerName nvarchar(400), Subject nvarchar(400), ExpiryDate datetime, Thumbprint varbinary(32));

DECLARE @DbName sysname, @Sql nvarchar(max);
DECLARE enc_db_cursor CURSOR LOCAL FAST_FORWARD FOR
    SELECT name FROM sys.databases WHERE state_desc = 'ONLINE';
OPEN enc_db_cursor;
FETCH NEXT FROM enc_db_cursor INTO @DbName;
WHILE @@FETCH_STATUS = 0
BEGIN
    SET @Sql = N'
    USE ' + QUOTENAME(@DbName) + N';
    INSERT INTO #DMKPresence (DatabaseName, KeyAlgorithm, KeyLength)
    SELECT DB_NAME(), key_algorithm, key_length
    FROM sys.symmetric_keys WHERE name = ''##MS_DatabaseMasterKey##'';

    IF DB_ID() > 4
        INSERT INTO #UserCerts (DatabaseName, CertificateName, IssuerName, Subject, ExpiryDate, Thumbprint)
        SELECT DB_NAME(), name, issuer_name, subject, expiry_date, thumbprint
        FROM sys.certificates WHERE name NOT LIKE ''##%##'';';
    EXEC sp_executesql @Sql;
    FETCH NEXT FROM enc_db_cursor INTO @DbName;
END
CLOSE enc_db_cursor;
DEALLOCATE enc_db_cursor;

DECLARE @DMK_Count int = (SELECT COUNT(*) FROM #DMKPresence);
DECLARE @UserCert_Count int = (SELECT COUNT(*) FROM #UserCerts);

-- Always Encrypted (requires the column_master_keys/column_encryption_keys
-- catalog views and sys.columns.encryption_type to exist - checked via
-- OBJECT_ID/COL_LENGTH rather than a major-version number, so this is safe
-- regardless of exact CU/SP backport history).
IF OBJECT_ID('tempdb..#AECMK') IS NOT NULL DROP TABLE #AECMK;
CREATE TABLE #AECMK (DatabaseName sysname, KeyName sysname, KeyStoreProvider nvarchar(260), KeyPath nvarchar(max));
IF OBJECT_ID('tempdb..#AECEK') IS NOT NULL DROP TABLE #AECEK;
CREATE TABLE #AECEK (DatabaseName sysname, KeyName sysname, ColumnMasterKeyName sysname, Algorithm nvarchar(60));
IF OBJECT_ID('tempdb..#AEColumns') IS NOT NULL DROP TABLE #AEColumns;
CREATE TABLE #AEColumns (DatabaseName sysname, SchemaName sysname, TableName sysname, ColumnName sysname, EncryptionType nvarchar(60), Algorithm nvarchar(60));

DECLARE @AE_Available bit = CASE WHEN OBJECT_ID('sys.column_master_keys') IS NOT NULL
                                   AND COL_LENGTH('sys.columns', 'encryption_type') IS NOT NULL
                              THEN 1 ELSE 0 END;
IF @AE_Available = 1
BEGIN
    DECLARE @AEDbName sysname, @AESql nvarchar(max);
    DECLARE ae_db_cursor CURSOR LOCAL FAST_FORWARD FOR
        SELECT name FROM sys.databases WHERE database_id > 4 AND state_desc = 'ONLINE';
    OPEN ae_db_cursor;
    FETCH NEXT FROM ae_db_cursor INTO @AEDbName;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @AESql = N'
        USE ' + QUOTENAME(@AEDbName) + N';
        INSERT INTO #AECMK (DatabaseName, KeyName, KeyStoreProvider, KeyPath)
        SELECT DB_NAME(), name, key_store_provider_name, key_path FROM sys.column_master_keys;

        INSERT INTO #AECEK (DatabaseName, KeyName, ColumnMasterKeyName, Algorithm)
        SELECT DB_NAME(), cek.name, cmk.name, cekv.encryption_algorithm_name
        FROM sys.column_encryption_keys AS cek
        JOIN sys.column_encryption_key_values AS cekv ON cek.column_encryption_key_id = cekv.column_encryption_key_id
        JOIN sys.column_master_keys AS cmk ON cekv.column_master_key_id = cmk.column_master_key_id;

        INSERT INTO #AEColumns (DatabaseName, SchemaName, TableName, ColumnName, EncryptionType, Algorithm)
        SELECT DB_NAME(), OBJECT_SCHEMA_NAME(c.object_id), OBJECT_NAME(c.object_id), c.name, c.encryption_type_desc, c.encryption_algorithm_name
        FROM sys.columns AS c WHERE c.encryption_type IS NOT NULL;';
        EXEC sp_executesql @AESql;
        FETCH NEXT FROM ae_db_cursor INTO @AEDbName;
    END
    CLOSE ae_db_cursor;
    DEALLOCATE ae_db_cursor;
END
DECLARE @AE_Col_Count int = (SELECT COUNT(*) FROM #AEColumns);

-- Native backup encryption (checked via COL_LENGTH on msdb.dbo.backupset,
-- not a major-version number, for the same patch-level-safety reason).
DECLARE @BackupEnc_Available bit = CASE WHEN COL_LENGTH('msdb.dbo.backupset', 'encryptor_type') IS NOT NULL THEN 1 ELSE 0 END;
DECLARE @BackupEnc_Count int = 0;
IF @BackupEnc_Available = 1
    EXEC sp_executesql N'SELECT @cnt = COUNT(*) FROM msdb.dbo.backupset WHERE encryptor_type IS NOT NULL', N'@cnt int OUTPUT', @cnt = @BackupEnc_Count OUTPUT;

-- -----------------------------------------------------------------------
-- SECTION 0: QUICK YES/NO SUMMARY
-- -----------------------------------------------------------------------
SELECT
    CASE WHEN @TDE_Count > 0 THEN 'YES' ELSE 'NO' END AS TDE_InUse,
    @TDE_Count AS TDE_EncryptedDatabaseCount,
    CASE WHEN @CertMaster_Count > 0 THEN 'YES' ELSE 'NO' END AS Certificates_In_Master,
    @CertMaster_Count AS Certificates_In_Master_Count,
    CASE WHEN @EKM_Count > 0 THEN 'YES' ELSE 'NO' END AS EKM_HSM_Provider_Registered,
    @EKM_Count AS EKM_Provider_Count,
    CASE WHEN @DMK_Count > 0 THEN 'YES' ELSE 'NO' END AS DatabaseMasterKey_Present_AnyDB,
    @DMK_Count AS DatabaseMasterKey_Count,
    CASE WHEN @UserCert_Count > 0 THEN 'YES' ELSE 'NO' END AS Certificates_In_UserDatabases,
    @UserCert_Count AS Certificates_In_UserDatabases_Count,
    CASE WHEN @AE_Available = 0 THEN 'N/A (feature not available on this version/patch level)' WHEN @AE_Col_Count > 0 THEN 'YES' ELSE 'NO' END AS AlwaysEncrypted_InUse,
    @AE_Col_Count AS AlwaysEncrypted_ColumnCount,
    CASE WHEN @BackupEnc_Available = 0 THEN 'N/A (feature not available on this version/patch level)' WHEN @BackupEnc_Count > 0 THEN 'YES' ELSE 'NO' END AS NativeBackupEncryption_InUse,
    @BackupEnc_Count AS NativeBackupEncryption_BackupCount;

-- NOTE: if everything above is NO, encryption is effectively not in use on
-- this instance and the migration can treat it as a non-issue for this
-- topic. Any YES needs the matching detail section below before cutover.

-- =========================================================================
-- DETAIL (drill down only into the sections flagged YES above)
-- =========================================================================

-- -----------------------------------------------------------------------
-- 1) TDE detail
-- -----------------------------------------------------------------------
SELECT
    d.name AS DatabaseName,
    d.is_encrypted,
    dek.encryption_state,
    dek.encryptor_type,
    dek.key_algorithm,
    dek.key_length,
    dek.encryptor_thumbprint
FROM sys.databases AS d
LEFT JOIN sys.dm_database_encryption_keys AS dek ON d.database_id = dek.database_id
WHERE dek.encryption_state IS NOT NULL
ORDER BY d.name;

-- -----------------------------------------------------------------------
-- 2) EKM/HSM providers, credentials, asymmetric keys bound to a provider
-- -----------------------------------------------------------------------
SELECT * FROM sys.cryptographic_providers ORDER BY name;
SELECT credential_id, name AS CredentialName, credential_identity, create_date, modify_date FROM sys.credentials ORDER BY name;
SELECT name AS AsymmetricKeyName, algorithm_desc, key_length, provider_type, cryptographic_provider_guid, thumbprint
FROM sys.asymmetric_keys WHERE name NOT LIKE '##%##' ORDER BY name;

-- -----------------------------------------------------------------------
-- 3) Certificates in master + Database Master Keys + certificates in user DBs
-- -----------------------------------------------------------------------
SELECT name AS CertificateName, certificate_id, pvt_key_encryption_type_desc, issuer_name, subject, expiry_date, thumbprint
FROM sys.certificates WHERE name NOT LIKE '##%##' ORDER BY name;

SELECT * FROM #DMKPresence ORDER BY DatabaseName;
SELECT * FROM #UserCerts ORDER BY DatabaseName, CertificateName;

-- -----------------------------------------------------------------------
-- 4) Always Encrypted detail (requires column_master_keys/encryption_type
--    catalog support)
-- -----------------------------------------------------------------------
IF @AE_Available = 1
BEGIN
    SELECT * FROM #AECMK ORDER BY DatabaseName, KeyName;
    SELECT * FROM #AECEK ORDER BY DatabaseName, KeyName;
    SELECT * FROM #AEColumns ORDER BY DatabaseName, SchemaName, TableName, ColumnName;
END
ELSE
    SELECT 'Always Encrypted catalog views are not available on this SQL Server version/patch level (requires SQL Server 2016+). This instance: SQL Server ' + CAST(@MajorVersion AS varchar(10)) AS Note;

-- -----------------------------------------------------------------------
-- 5) Native backup encryption detail (requires backupset.encryptor_type)
-- -----------------------------------------------------------------------
IF @BackupEnc_Available = 1
BEGIN
    EXEC('
    SELECT database_name,
           CASE type WHEN ''D'' THEN ''FULL'' WHEN ''I'' THEN ''DIFFERENTIAL'' WHEN ''L'' THEN ''LOG'' ELSE type END AS BackupType,
           backup_start_date, key_algorithm, encryptor_thumbprint, encryptor_type
    FROM msdb.dbo.backupset
    WHERE encryptor_type IS NOT NULL
    ORDER BY database_name, backup_start_date DESC;');
END
ELSE
    SELECT 'Native backup encryption columns are not available in SQL Server 2012 (feature introduced in SQL Server 2014). If backups are encrypted on this version, it is being done by third-party backup software - check with the backup/infra team.' AS Note;

DROP TABLE #DMKPresence;
DROP TABLE #UserCerts;
DROP TABLE #AECMK;
DROP TABLE #AECEK;
DROP TABLE #AEColumns;

-- IMPORTANT: inventory does not equal backup/export. Before migration,
-- separately verify that all required TDE certificates/private keys or
-- EKM/HSM keys are available and recoverable on the OCI target. Never
-- expose private key passwords in reports.
