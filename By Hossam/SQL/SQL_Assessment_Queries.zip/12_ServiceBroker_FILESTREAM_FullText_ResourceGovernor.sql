SET NOCOUNT ON;
DECLARE @MajorVersion int = CAST(SERVERPROPERTY('ProductMajorVersion') AS int);

-- Service Broker
DECLARE @SB_DbCount int = (SELECT COUNT(*) FROM sys.databases WHERE is_broker_enabled = 1);

-- FILESTREAM
DECLARE @FS_ConfiguredLevel sql_variant = SERVERPROPERTY('FilestreamConfiguredLevel');
DECLARE @FS_FileCount int = (SELECT COUNT(*) FROM sys.master_files WHERE type_desc = 'FILESTREAM');

-- Full-Text
DECLARE @FT_Installed sql_variant = SERVERPROPERTY('IsFullTextInstalled');
DECLARE @FT_DbCount int = (SELECT COUNT(*) FROM sys.databases WHERE database_id > 4 AND DATABASEPROPERTYEX(name, 'IsFulltextEnabled') = 1);

-- Resource Governor
DECLARE @RG_Enabled bit = (SELECT is_enabled FROM sys.resource_governor_configuration);
DECLARE @RG_CustomPoolCount int = (SELECT COUNT(*) FROM sys.resource_governor_resource_pools WHERE name NOT IN ('default','internal'));

SELECT
    CASE WHEN @SB_DbCount > 0 THEN 'YES' ELSE 'NO' END AS ServiceBroker_InUse,
    @SB_DbCount AS ServiceBroker_EnabledDatabaseCount,
    CASE WHEN CAST(@FS_ConfiguredLevel AS int) > 0 THEN 'YES' ELSE 'NO' END AS FILESTREAM_Configured,
    CASE WHEN @FS_FileCount > 0 THEN 'YES' ELSE 'NO' END AS FILESTREAM_ActuallyUsed,
    @FS_FileCount AS FILESTREAM_FileCount,
    CASE WHEN CAST(@FT_Installed AS int) = 1 THEN 'YES' ELSE 'NO' END AS FullText_Installed,
    CASE WHEN @FT_DbCount > 0 THEN 'YES' ELSE 'NO' END AS FullText_ActuallyUsed,
    @FT_DbCount AS FullText_EnabledDatabaseCount,
    CASE WHEN @RG_Enabled = 1 OR @RG_CustomPoolCount > 0 THEN 'YES' ELSE 'NO' END AS ResourceGovernor_InUse,
    @RG_Enabled AS ResourceGovernor_Enabled,
    @RG_CustomPoolCount AS ResourceGovernor_CustomPoolCount;

-- NOTE: a YES on any flag means that feature must be accounted for in the
-- cutover plan (Service Broker needs its queues/routes/certificates
-- re-established on the target; FILESTREAM needs the Windows feature and
-- share re-created; Full-Text catalogs need to be rebuilt on restore;
-- Resource Governor pools/classifier function need to be scripted out and
-- re-applied). If you need the full object-level detail for a YES here
-- (queue/route names, FILESTREAM tables/columns, Full-Text catalogs/
-- indexes, resource pool/workload group settings), ask and a drill-down
-- script can be added back for that specific feature.
