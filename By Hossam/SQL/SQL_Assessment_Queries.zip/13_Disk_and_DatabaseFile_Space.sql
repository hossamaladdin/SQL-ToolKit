-- -----------------------------------------------------------------------
-- PART 1: Disk volume free space (OS-level, per mount point/drive)
-- -----------------------------------------------------------------------
SELECT
    vs.volume_mount_point AS Drive,
    vs.logical_volume_name AS VolumeName,
    CASE
        WHEN MIN(vs.available_bytes) >= 1073741824
            THEN CONCAT(CAST(MIN(vs.available_bytes) / 1073741824.0 AS DECIMAL(10,2)), ' GB')
        ELSE CONCAT(CAST(MIN(vs.available_bytes) / 1048576.0 AS DECIMAL(10,2)), ' MB')
    END AS FreeSpace,
    CASE
        WHEN MAX(vs.total_bytes) >= 1073741824
            THEN CONCAT(CAST(MAX(vs.total_bytes) / 1073741824.0 AS DECIMAL(10,2)), ' GB')
        ELSE CONCAT(CAST(MAX(vs.total_bytes) / 1048576.0 AS DECIMAL(10,2)), ' MB')
    END AS TotalSpace,
    CAST(MIN(vs.available_bytes) * 100.0 / MAX(vs.total_bytes) AS DECIMAL(5,2)) AS FreePercent,
    CASE
        WHEN CAST(MIN(vs.available_bytes) * 100.0 / MAX(vs.total_bytes) AS DECIMAL(5,2)) < 15.00
            THEN 'WARNING: Below 15% free'
        ELSE 'OK'
    END AS Status
FROM sys.master_files AS mf
CROSS APPLY sys.dm_os_volume_stats(mf.database_id, mf.file_id) AS vs
GROUP BY vs.volume_mount_point, vs.logical_volume_name
ORDER BY FreePercent;

-- NOTE: this reports every volume hosting a SQL Server data/log/backup
-- file for THIS instance only. For OCI storage sizing, cross-reference
-- across all instances/servers being migrated, since the same volume may
-- host files for multiple instances.

-- -----------------------------------------------------------------------
-- PART 2: Per-database-file used/free space and shrink candidates
-- -----------------------------------------------------------------------
IF OBJECT_ID('tempdb..#DBFileSpaceInfo') IS NOT NULL
    DROP TABLE #DBFileSpaceInfo;

CREATE TABLE #DBFileSpaceInfo
(
    DatabaseName    NVARCHAR(128),
    FileName        NVARCHAR(128),
    PhysicalName    NVARCHAR(260),
    FileType        NVARCHAR(60),
    TotalSizeMB     DECIMAL(18,2),
    UsedSpaceMB     DECIMAL(18,2),
    FreeSpaceMB     DECIMAL(18,2),
    FreePercentage  DECIMAL(5,2),
    ShrinkCommand   NVARCHAR(1000)
);

DECLARE @DbName sysname, @Sql nvarchar(max);
DECLARE dbfile_cursor CURSOR LOCAL FAST_FORWARD FOR
    SELECT name FROM sys.databases WHERE state_desc = 'ONLINE';
OPEN dbfile_cursor;
FETCH NEXT FROM dbfile_cursor INTO @DbName;
WHILE @@FETCH_STATUS = 0
BEGIN
    SET @Sql = N'
    USE ' + QUOTENAME(@DbName) + N';
    INSERT INTO #DBFileSpaceInfo
    SELECT
        DB_NAME() AS DatabaseName,
        name AS FileName,
        physical_name AS PhysicalName,
        type_desc AS FileType,
        size / 128.0 AS TotalSizeMB,
        CAST(FILEPROPERTY(name, ''SpaceUsed'') AS bigint) / 128.0 AS UsedSpaceMB,
        size / 128.0 - CAST(FILEPROPERTY(name, ''SpaceUsed'') AS bigint) / 128.0 AS FreeSpaceMB,
        CASE WHEN size = 0 THEN 0 ELSE
            ((size / 128.0 - CAST(FILEPROPERTY(name, ''SpaceUsed'') AS bigint) / 128.0) / (size / 128.0)) * 100
        END AS FreePercentage,
        CASE
            WHEN type = 0 THEN
                ''USE '' + QUOTENAME(DB_NAME()) + N''; DBCC SHRINKFILE (N'''''' + name + '''''', ''
                + CONVERT(NVARCHAR(20), CAST(CAST(FILEPROPERTY(name, ''SpaceUsed'') AS bigint) * 8.0 / 1024 * 1.10 AS bigint))
                + ''); -- data file, shrinks to ~10% above current used space''
            WHEN type = 1 THEN
                ''USE '' + QUOTENAME(DB_NAME()) + N''; DBCC SHRINKFILE (N'''''' + name + ''''''); -- log file''
            ELSE N''''
        END AS ShrinkCommand
    FROM sys.database_files
    WHERE type IN (0,1);';
    EXEC sp_executesql @Sql;
    FETCH NEXT FROM dbfile_cursor INTO @DbName;
END
CLOSE dbfile_cursor;
DEALLOCATE dbfile_cursor;

SELECT *
FROM #DBFileSpaceInfo
ORDER BY FreeSpaceMB DESC;

DROP TABLE #DBFileSpaceInfo;

-- IMPORTANT: shrink commands are suggestions only, generated from current
-- used-space snapshot plus 10% headroom. Do NOT run DBCC SHRINKFILE
-- blindly/routinely - it causes index fragmentation. Review per database
-- before migration cutover, when a one-time size reduction to limit data
-- transferred/restored to OCI may be worthwhile; otherwise avoid shrinking
-- actively-used data files in general practice.
