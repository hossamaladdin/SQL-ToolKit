-- -----------------------------------------------------------------------
-- 1) Role flags - is this instance a Publisher / Distributor / Subscriber
--    at all, before running the (noisier) sp_help* procs below
-- -----------------------------------------------------------------------
SELECT
    name AS DatabaseName,
    is_published,
    is_subscribed,
    is_merge_published,
    is_distributor
FROM sys.databases
WHERE is_published = 1 OR is_subscribed = 1 OR is_merge_published = 1 OR is_distributor = 1
ORDER BY name;

IF (SELECT COUNT(*) FROM sys.databases WHERE is_published = 1 OR is_subscribed = 1 OR is_merge_published = 1 OR is_distributor = 1) = 0
    SELECT 'No databases on this instance are flagged as published/subscribed/distributor - replication does not appear to be configured here.' AS Note;

-- -----------------------------------------------------------------------
-- 2) Is this instance configured as a Distributor?
-- -----------------------------------------------------------------------
BEGIN TRY
    EXEC sp_helpdistributor;
END TRY
BEGIN CATCH
    SELECT 'sp_helpdistributor failed or distribution is not configured: ' + ERROR_MESSAGE() AS Note;
END CATCH

-- -----------------------------------------------------------------------
-- 3) Publications (run on a Publisher) - transactional/snapshot/merge
-- -----------------------------------------------------------------------
IF EXISTS (SELECT 1 FROM sys.databases WHERE is_published = 1 OR is_merge_published = 1)
BEGIN
    -- Looping over sys.databases explicitly instead of sp_MSforeachdb (see
    -- note in script 09/10 - sp_MSforeachdb can silently skip databases).
    DECLARE @PubDbName sysname, @PubSql nvarchar(max);
    DECLARE pub_db_cursor CURSOR LOCAL FAST_FORWARD FOR
        SELECT name FROM sys.databases
        WHERE database_id > 4 AND (is_published = 1 OR is_merge_published = 1);
    OPEN pub_db_cursor;
    FETCH NEXT FROM pub_db_cursor INTO @PubDbName;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @PubSql = N'
        USE ' + QUOTENAME(@PubDbName) + N';
        EXEC sp_helppublication;
        EXEC sp_helparticle @publication = N''%'';';
        EXEC sp_executesql @PubSql;
        FETCH NEXT FROM pub_db_cursor INTO @PubDbName;
    END
    CLOSE pub_db_cursor;
    DEALLOCATE pub_db_cursor;
END

-- -----------------------------------------------------------------------
-- 4) Subscriptions (run on a Subscriber)
-- -----------------------------------------------------------------------
IF EXISTS (SELECT 1 FROM sys.databases WHERE is_subscribed = 1)
BEGIN
    DECLARE @SubDbName sysname, @SubSql nvarchar(max);
    DECLARE sub_db_cursor CURSOR LOCAL FAST_FORWARD FOR
        SELECT name FROM sys.databases WHERE database_id > 4 AND is_subscribed = 1;
    OPEN sub_db_cursor;
    FETCH NEXT FROM sub_db_cursor INTO @SubDbName;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @SubSql = N'
        USE ' + QUOTENAME(@SubDbName) + N';
        EXEC sp_helpsubscription;';
        EXEC sp_executesql @SubSql;
        FETCH NEXT FROM sub_db_cursor INTO @SubDbName;
    END
    CLOSE sub_db_cursor;
    DEALLOCATE sub_db_cursor;
END

-- -----------------------------------------------------------------------
-- 5) Replication Agent jobs (these show up in zip Q09's job list too, but
--    without the replication-specific context) - isolate just the
--    replication agent subsystems here for quick triage
-- -----------------------------------------------------------------------
SELECT
    j.name AS JobName,
    j.enabled,
    js.subsystem,
    js.command
FROM msdb.dbo.sysjobs AS j
JOIN msdb.dbo.sysjobsteps AS js ON j.job_id = js.job_id
WHERE js.subsystem IN ('Snapshot','LogReader','Distribution','Merge','QueueReader')
ORDER BY j.name, js.step_id;

-- NOTE:
-- If any rows were returned above, replication must be accounted for in
-- the cutover plan (it is incompatible with simple backup/restore unless
-- re-initialized, and needs the distribution database and agent jobs
-- recreated on the target). If no rows anywhere in this script, replication
-- is not in use and can be dropped from the cutover checklist.
