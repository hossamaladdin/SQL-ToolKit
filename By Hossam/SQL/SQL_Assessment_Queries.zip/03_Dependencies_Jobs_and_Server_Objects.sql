-- -----------------------------------------------------------------------
-- Q08. Are there any remote queries or dependencies on other SQL Servers?
-- -----------------------------------------------------------------------
-- Linked Servers:
SELECT
    server_id,
    name AS LinkedServerName,
    product,
    provider,
    data_source,
    provider_string,
    catalog,
    is_linked,
    is_data_access_enabled,
    is_rpc_out_enabled,
    is_remote_proc_transaction_promotion_enabled
FROM sys.servers
WHERE server_id <> 0
ORDER BY name;

-- Synonyms that may point outside the local database/server:
DECLARE @SynDbName sysname, @SynSql nvarchar(max);
DECLARE syn_db_cursor CURSOR LOCAL FAST_FORWARD FOR
    SELECT name FROM sys.databases WHERE database_id > 4 AND state_desc = 'ONLINE';
OPEN syn_db_cursor;
FETCH NEXT FROM syn_db_cursor INTO @SynDbName;
WHILE @@FETCH_STATUS = 0
BEGIN
    SET @SynSql = N'
    USE ' + QUOTENAME(@SynDbName) + N';
    SELECT DB_NAME() AS DatabaseName, name AS SynonymName, base_object_name
    FROM sys.synonyms;';
    EXEC sp_executesql @SynSql;
    FETCH NEXT FROM syn_db_cursor INTO @SynDbName;
END
CLOSE syn_db_cursor;
DEALLOCATE syn_db_cursor;
-- NOTE: no single T-SQL query can guarantee discovery of every external
-- dependency. Application code, dynamic SQL, SSIS packages, scripts,
-- connection strings and job steps must also be reviewed.

-- -----------------------------------------------------------------------
-- Q09. What maintenance plans or SQL Agent maintenance jobs are configured?
-- -----------------------------------------------------------------------
-- Maintenance Plans:
SELECT
    p.id AS PlanID,
    p.name AS MaintenancePlanName,
    p.description,
    p.owner
FROM msdb.dbo.sysmaintplan_plans AS p
ORDER BY p.name;

-- All SQL Agent jobs:
SELECT
    j.job_id,
    j.name AS JobName,
    SUSER_SNAME(j.owner_sid) AS Owner,
    j.enabled,
    c.name AS Category,
    j.description,
    s.name AS ScheduleName,
    s.enabled AS ScheduleEnabled,
    CASE s.freq_type
        WHEN 1 THEN 'Once'
        WHEN 4 THEN 'Daily'
        WHEN 8 THEN 'Weekly'
        WHEN 16 THEN 'Monthly'
        WHEN 32 THEN 'Monthly Relative'
        WHEN 64 THEN 'SQL Agent Start'
        WHEN 128 THEN 'Computer Idle'
        ELSE CAST(s.freq_type AS varchar(20))
    END AS FrequencyType
FROM msdb.dbo.sysjobs AS j
LEFT JOIN msdb.dbo.syscategories AS c ON j.category_id = c.category_id
LEFT JOIN msdb.dbo.sysjobschedules AS js ON j.job_id = js.job_id
LEFT JOIN msdb.dbo.sysschedules AS s ON js.schedule_id = s.schedule_id
ORDER BY j.name;

-- Job steps (important for dependencies, SSIS, PowerShell, CmdExec, remote servers):
SELECT
    j.name AS JobName,
    js.step_id,
    js.step_name,
    js.subsystem,
    js.database_name,
    js.command,
    js.proxy_id
FROM msdb.dbo.sysjobs AS j
JOIN msdb.dbo.sysjobsteps AS js ON j.job_id = js.job_id
ORDER BY j.name, js.step_id;

-- -----------------------------------------------------------------------
-- Q22. What SQL Server Agent Jobs, Linked Servers, Credentials, Proxies,
--      Operators, Alerts, and Database Mail configurations must be migrated?
-- -----------------------------------------------------------------------
-- Jobs: see Q09 above. Linked Servers: see Q08 above.

-- Credentials:
SELECT credential_id, name, credential_identity, create_date, modify_date
FROM sys.credentials
ORDER BY name;

-- Agent Proxies:
SELECT
    p.proxy_id,
    p.name AS ProxyName,
    c.name AS CredentialName,
    p.enabled,
    p.description
FROM msdb.dbo.sysproxies AS p
LEFT JOIN sys.credentials AS c ON p.credential_id = c.credential_id
ORDER BY p.name;

-- Operators:
SELECT
    id, name, enabled, email_address, pager_address, netsend_address
FROM msdb.dbo.sysoperators
ORDER BY name;

-- Alerts:
SELECT
    id, name, event_source, event_category_id, event_id,
    message_id, severity, enabled, delay_between_responses
FROM msdb.dbo.sysalerts
ORDER BY name;

-- Database Mail accounts/profiles:
SELECT
    a.account_id,
    a.name AS AccountName,
    a.email_address,
    a.display_name,
    s.servername AS SMTPServer,
    s.port,
    s.enable_ssl
FROM msdb.dbo.sysmail_account AS a
LEFT JOIN msdb.dbo.sysmail_server AS s ON a.account_id = s.account_id
ORDER BY a.name;

SELECT
    p.profile_id,
    p.name AS ProfileName,
    p.description,
    a.name AS AccountName,
    pa.sequence_number
FROM msdb.dbo.sysmail_profile AS p
LEFT JOIN msdb.dbo.sysmail_profileaccount AS pa ON p.profile_id = pa.profile_id
LEFT JOIN msdb.dbo.sysmail_account AS a ON pa.account_id = a.account_id
ORDER BY p.name, pa.sequence_number;

-- -----------------------------------------------------------------------
-- Q23. Are SSIS, SSRS, or SSAS components used by applications or Agent jobs?
-- -----------------------------------------------------------------------
-- SQL Agent steps reveal SSIS subsystem usage:
SELECT
    j.name AS JobName,
    s.step_id,
    s.step_name,
    s.subsystem,
    s.command
FROM msdb.dbo.sysjobs AS j
JOIN msdb.dbo.sysjobsteps AS s ON j.job_id = s.job_id
WHERE s.subsystem IN ('SSIS','ANALYSISQUERY','ANALYSISCOMMAND')
   OR s.command LIKE '%SSIS%'
   OR s.command LIKE '%ReportServer%'
ORDER BY j.name, s.step_id;

-- SSISDB presence:
SELECT
    name,
    state_desc,
    compatibility_level
FROM sys.databases
WHERE name = 'SSISDB';
-- NOTE: installed SSRS/SSAS Windows services are best verified with the
-- zip's PowerShell service inventory. Application use must be confirmed
-- with application owners. For SSISDB/SSRS catalog detail beyond presence,
-- see script 09 in this folder.

-- -----------------------------------------------------------------------
-- Q24. Are there server-level triggers, endpoints, CLR assemblies, or
--      other server-level objects that must be migrated?
-- -----------------------------------------------------------------------
-- Server triggers:
SELECT
    name,
    parent_class_desc,
    create_date,
    modify_date,
    is_disabled
FROM sys.server_triggers
ORDER BY name;

-- Endpoints:
SELECT
    e.name,
    e.endpoint_id,
    e.type_desc,
    e.state_desc,
    e.protocol_desc,
    te.port,
    te.ip_address
FROM sys.endpoints AS e
LEFT JOIN sys.tcp_endpoints AS te ON e.endpoint_id = te.endpoint_id
ORDER BY e.endpoint_id;

-- Server configuration values that may need comparison:
SELECT name, value, value_in_use, description
FROM sys.configurations
ORDER BY name;

-- CLR enabled:
SELECT name, value_in_use
FROM sys.configurations
WHERE name IN ('clr enabled','clr strict security');

-- User CLR assemblies in each online user database:
DECLARE @ClrDbName sysname, @ClrSql nvarchar(max);
DECLARE clr_db_cursor CURSOR LOCAL FAST_FORWARD FOR
    SELECT name FROM sys.databases WHERE database_id > 4 AND state_desc = 'ONLINE';
OPEN clr_db_cursor;
FETCH NEXT FROM clr_db_cursor INTO @ClrDbName;
WHILE @@FETCH_STATUS = 0
BEGIN
    SET @ClrSql = N'
    USE ' + QUOTENAME(@ClrDbName) + N';
    SELECT DB_NAME() AS DatabaseName,
           name AS AssemblyName,
           permission_set_desc,
           create_date
    FROM sys.assemblies
    WHERE is_user_defined = 1;';
    EXEC sp_executesql @ClrSql;
    FETCH NEXT FROM clr_db_cursor INTO @ClrDbName;
END
CLOSE clr_db_cursor;
DEALLOCATE clr_db_cursor;

-- -----------------------------------------------------------------------
-- Q25. What SQL logins and server-level permissions must be migrated
--      while preserving existing SIDs?
-- -----------------------------------------------------------------------
SELECT
    sp.name AS LoginName,
    sp.type_desc,
    sp.sid,
    sp.default_database_name,
    sp.default_language_name,
    sp.is_disabled,
    sl.is_policy_checked,
    sl.is_expiration_checked
FROM sys.server_principals AS sp
LEFT JOIN sys.sql_logins AS sl ON sp.principal_id = sl.principal_id
WHERE sp.type IN ('S','U','G','E','X')
  AND sp.name NOT LIKE '##%##'
  AND sp.name NOT LIKE 'NT SERVICE\%'
  AND sp.name NOT LIKE 'NT AUTHORITY\%'
ORDER BY sp.type_desc, sp.name;

-- Server role membership:
SELECT
    rolep.name AS ServerRole,
    memberp.name AS MemberName
FROM sys.server_role_members AS srm
JOIN sys.server_principals AS rolep ON srm.role_principal_id = rolep.principal_id
JOIN sys.server_principals AS memberp ON srm.member_principal_id = memberp.principal_id
ORDER BY rolep.name, memberp.name;

-- Explicit server permissions:
SELECT
    grantee.name AS Grantee,
    perm.state_desc,
    perm.permission_name,
    perm.class_desc
FROM sys.server_permissions AS perm
JOIN sys.server_principals AS grantee
    ON perm.grantee_principal_id = grantee.principal_id
ORDER BY grantee.name, perm.permission_name;

-- NOTE: for SQL-authenticated logins, use Microsoft's sp_help_revlogin-style
-- method or an approved equivalent during migration so password hashes and
-- SIDs are preserved. Do not expose password hashes in assessment reports.
