-- -----------------------------------------------------------------------
-- Q14. What is the current SQL Server architecture for each instance:
--      Standalone, FCI, or Always On Availability Group?
-- -----------------------------------------------------------------------
SELECT
    @@SERVERNAME AS ServerName,
    SERVERPROPERTY('IsClustered') AS IsFCI,
    SERVERPROPERTY('IsHadrEnabled') AS IsAlwaysOnEnabled,
    SERVERPROPERTY('ComputerNamePhysicalNetBIOS') AS CurrentPhysicalNode,
    SERVERPROPERTY('MachineName') AS MachineName,
    SERVERPROPERTY('InstanceName') AS InstanceName;

-- AG presence:
SELECT name AS AvailabilityGroupName
FROM sys.availability_groups;

-- INTERPRETATION: IsClustered = 1 => SQL Server FCI. IsHadrEnabled = 1 and
-- AG rows exist => Always On AG configured. Both may coexist in some
-- designs; do not assume architecture from one flag alone.

-- -----------------------------------------------------------------------
-- Q15. How many Windows cluster nodes and SQL Server replicas are
--      configured?
--      FIX: seeding_mode_desc version-gated (SQL 2016+ only).
-- -----------------------------------------------------------------------
-- Windows cluster members visible to SQL Server:
SELECT
    member_name,
    member_type_desc,
    member_state_desc,
    number_of_quorum_votes
FROM sys.dm_hadr_cluster_members;

-- seeding_mode_desc was added for Direct Seeding support. Guarded via
-- COL_LENGTH rather than a major-version number, so this is safe even if
-- a future CU/SP backports the column to an earlier major version.
IF COL_LENGTH('sys.availability_replicas', 'seeding_mode_desc') IS NOT NULL
BEGIN
    EXEC('
    SELECT
        ag.name AS AGName,
        ar.replica_server_name,
        ar.availability_mode_desc,
        ar.failover_mode_desc,
        ar.seeding_mode_desc,
        ar.endpoint_url
    FROM sys.availability_groups AS ag
    JOIN sys.availability_replicas AS ar
        ON ag.group_id = ar.group_id
    ORDER BY ag.name, ar.replica_server_name;');
END
ELSE
BEGIN
    SELECT
        ag.name AS AGName,
        ar.replica_server_name,
        ar.availability_mode_desc,
        ar.failover_mode_desc,
        ar.endpoint_url
    FROM sys.availability_groups AS ag
    JOIN sys.availability_replicas AS ar
        ON ag.group_id = ar.group_id
    ORDER BY ag.name, ar.replica_server_name;
END
-- NOTE: for FCI node inventory independent of AG, run the zip's
-- PowerShell cluster commands.

-- -----------------------------------------------------------------------
-- Q16. What are the AG names, Listener names, Listener IPs, and endpoint
--      ports?
-- Q17A. Are AGs synchronous or asynchronous?
-- Q17B. What is the failover mode: Automatic or Manual?
-- Q17C. Are any SQL Server instances using multiple subnets?
--      FIX: seeding_mode_desc version-gated (SQL 2016+ only).
-- -----------------------------------------------------------------------
IF COL_LENGTH('sys.availability_replicas', 'seeding_mode_desc') IS NOT NULL
BEGIN
    EXEC('
    SELECT
        ag.name AS AGName,
        ar.replica_server_name,
        ar.endpoint_url,
        ar.availability_mode_desc,
        ar.failover_mode_desc,
        ar.seeding_mode_desc,
        ar.secondary_role_allow_connections_desc
    FROM sys.availability_groups AS ag
    JOIN sys.availability_replicas AS ar ON ag.group_id = ar.group_id
    ORDER BY ag.name, ar.replica_server_name;');
END
ELSE
BEGIN
    SELECT
        ag.name AS AGName,
        ar.replica_server_name,
        ar.endpoint_url,
        ar.availability_mode_desc,
        ar.failover_mode_desc,
        ar.secondary_role_allow_connections_desc
    FROM sys.availability_groups AS ag
    JOIN sys.availability_replicas AS ar ON ag.group_id = ar.group_id
    ORDER BY ag.name, ar.replica_server_name;
END

SELECT
    ag.name AS AGName,
    agl.dns_name AS ListenerName,
    agl.port AS ListenerPort,
    ip.ip_address AS ListenerIPAddress,
    ip.ip_subnet_mask AS SubnetMask,
    ip.network_subnet_ip,
    ip.network_subnet_prefix_length,
    ip.state_desc
FROM sys.availability_groups AS ag
JOIN sys.availability_group_listeners AS agl ON ag.group_id = agl.group_id
LEFT JOIN sys.availability_group_listener_ip_addresses AS ip
    ON agl.listener_id = ip.listener_id
ORDER BY ag.name, agl.dns_name, ip.ip_address;

-- Mirroring/HADR endpoint:
SELECT
    e.name AS EndpointName,
    e.state_desc,
    te.port,
    dme.role_desc,
    dme.connection_auth_desc,
    dme.encryption_algorithm_desc
FROM sys.database_mirroring_endpoints AS dme
JOIN sys.endpoints AS e ON dme.endpoint_id = e.endpoint_id
JOIN sys.tcp_endpoints AS te ON e.endpoint_id = te.endpoint_id;

-- NOTE: multiple listener IP rows in different network subnets indicate a
-- multi-subnet listener design. Confirm the Windows cluster network
-- topology with PowerShell.
